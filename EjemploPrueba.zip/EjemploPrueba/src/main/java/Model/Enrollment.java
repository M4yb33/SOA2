/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author DELL
 */
public class Enrollment {
    private int id;
    private String studentCedula;
    private int courseId;

    public Enrollment() {}

    public Enrollment(int id, String studentCedula, int courseId) {
        this.id = id;
        this.studentCedula = studentCedula;
        this.courseId = courseId;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getStudentCedula() { return studentCedula; }
    public void setStudentCedula(String studentCedula) { this.studentCedula = studentCedula; }

    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }
}
